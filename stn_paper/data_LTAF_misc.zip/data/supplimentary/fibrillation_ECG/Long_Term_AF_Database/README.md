# Long-Term AF Database Reference Annotations by MedicAlgorithmics

## Tables of beats and rhythms

These tables are derived from the atr (reference) annotations of the 
Long-Term AF Database.

The beat table shows the number of beats of each type in each record.
The rhythm table shows the number of episodes (N) and the total duration
of each rhythm observed in each record in the format "N (hh:mm:ss)".

